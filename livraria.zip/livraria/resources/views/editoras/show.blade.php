ID:{{$editora->id_editora}}<br>
Nome:{{$editora->nome}}<br>
Morada:{{$editora->morada}}

<h2>Livros:</h2>
@foreach ($editora->livros as $livro)
	<h4>{{$livro->titulo}}</h4>
@endforeach