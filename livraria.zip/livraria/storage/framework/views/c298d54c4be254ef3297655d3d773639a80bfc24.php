<form action="<?php echo e(route('livros.create')); ?>" method="post">
	<?php echo csrf_field(); ?>
	Título: <input type="text" name="titulo">
	<br>
	Idioma: <input type="text" name="idioma">
	<br>
	Total páginas: <input type="text" name="total_paginas">
	<br>
	Data Edição: <input type="text" name="data_edicao">
	<br>
	ISBN: <input type="text" name="isbn">
	<br>
	Observações: <textarea name="observacoes"></textarea>
	<br>
	Imagem capa: <input type="text" name="imagem_capa">
	<br>
	Genero: <input type="text" name="id_genero">
	<br>
	Autores: <input type="text" name="id_autor">
	<br>
	Sinópse: <textarea name="sinopse"></textarea>
	<br>
	<input type="submit" name="enviar">
</form><?php /**PATH C:\Users\Professor\Downloads\psiat6-main\livraria\resources\views/livros/create.blade.php ENDPATH**/ ?>