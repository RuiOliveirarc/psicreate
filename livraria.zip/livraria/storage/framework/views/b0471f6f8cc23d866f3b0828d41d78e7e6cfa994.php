<ul>
<?php $__currentLoopData = $autores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $autor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<li><?php echo e($autor->nome); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php echo e($autores->render()); ?><?php /**PATH D:\psiat2\livraria\resources\views/autores/index.blade.php ENDPATH**/ ?>