ID:<?php echo e($editora->id_editora); ?><br>
Nome:<?php echo e($editora->nome); ?><br>
Morada:<?php echo e($editora->morada); ?><?php /**PATH D:\psiat4\livraria\resources\views/editoras/show.blade.php ENDPATH**/ ?>